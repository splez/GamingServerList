<html>

<head>
</head>

<body style="background-color:#dbd9c2">

<header style="background-color:#8badb1">
<a href="index.php"><button style="font-size: 200%;background-color: 
#8badb1; border:none; ">GamingServerList</button></a>
</header>

<section>
<a href="myservers.php"><button style=" background-color: 
#b7cfbe;font-size: 200%;">MyServers</button></a>
<a href="createServer.php"><button style=" background-color: #b7cfbe;font-size: 200%;">Add Minecraft Server Listing</button></a>
</section>

</body>

</html>